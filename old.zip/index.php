<?php
header('Location: public/');
